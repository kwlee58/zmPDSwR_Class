# informalexample 10.3 of section 10.3.2 
# (informalexample 10.3 of section 10.3.2)  : Documentation and deployment : Using comments and version control for running documentation : Using version control to record history 

git add -A . 	# Note: 1 
git commit 	# Note: 2

# Note 1: 
#   Stage results to commit (specify what files 
#   should be committed). 

# Note 2: 
#   Actually perform the commit. 


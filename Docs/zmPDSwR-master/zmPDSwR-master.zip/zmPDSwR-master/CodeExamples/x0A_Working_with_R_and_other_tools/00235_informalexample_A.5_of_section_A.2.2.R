# informalexample A.5 of section A.2.2 
# (informalexample A.5 of section A.2.2)  : Working with R and other tools : Starting with R : Primary R data types 

> vec <- c(2,3)
> vec[[2]] <- 5
> print(vec)
[1] 2 5


# example A.12 of section A.3.4 
# (example A.12 of section A.3.4)  : Working with R and other tools : Using databases with R : An example SQL data transformation task 
# Title: The hotel reservation and price data 

> print(bookings)
        date day.of.stay X1.before X2.before X3.before
1 2013-07-01         105        98        95        96
2 2013-07-02         103       100        98        95
3 2013-07-03         105        95        90        80
4 2013-07-04         105       105       107        98
> print(prices)
        date day.of.stay X1.before X2.before X3.before
1 2013-07-01     $250.00   $200.00   $280.00   $300.00
2 2013-07-02     $200.00   $250.00   $290.00   $250.00
3 2013-07-03     $200.00   $200.00   $250.00   $275.00
4 2013-07-04     $250.00   $300.00   $300.00   $200.00

